class MQTTService:
    def __init__(self):
        print "Init MQTT Service"