from eventdetection.listener import EventListener

el = EventListener("objectSensorEventDetector",5)
