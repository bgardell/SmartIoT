import requests

class ExternalServiceDependency():
    def __init(self, externalDependencyDefinition):
        self.externalDependencyDefinition = externalDependencyDefinition

    def getExternalKnowledgeAsPredicates(self):
        pass

    def _requestExternalService(self):
        pass